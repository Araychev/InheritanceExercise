﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomRandomList
{
    class RandomList
    {
    }
}
